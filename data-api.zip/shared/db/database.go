package database

import (
	"database/sql"
	"log"
	"net/url"
	"strconv"

	mssql "github.com/microsoft/go-mssqldb"
)

var (
	debug    = false
	password = ""
	port     = 1433
	server   = "localhost"
	user     = ""
)

func makeConnURL() *url.URL {
	var userInfo *url.Userinfo
	userInfo = url.UserPassword(user, password)
	return &url.URL{
		Scheme: "sqlserver",
		Host:   server + ":" + strconv.Itoa(port),
		User:   userInfo,
	}
}

func GetConnection() (*sql.DB, error) {
	connString := makeConnURL().String()
	connector, err := mssql.NewConnector(connString)
	if err != nil {
		log.Println(err)
		return nil, err
	}

	// Pass connector to sql.OpenDB to get a sql.DB object
	db := sql.OpenDB(connector)
	err = PingConnection(db)
	if err != nil {
		log.Printf("Error in PingConnection: %v", err)
		return nil, err
	}
	return db, nil
}

func PingConnection(db *sql.DB) error {
	if err := db.Ping(); err != nil {
		log.Printf("Unable to connect to database: %v", err)
		return err
	}
	return nil
}
