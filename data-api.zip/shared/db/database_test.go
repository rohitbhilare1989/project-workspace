package database

import (
	"fmt"
	"testing"
)

func TestConnection(t *testing.T) {
	db, err := GetConnection()
	fmt.Println(db)
	fmt.Println(err)
}
