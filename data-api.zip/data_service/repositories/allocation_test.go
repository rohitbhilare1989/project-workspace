package repositories

import "testing"

func TestAllocateDeviceInBulk(t *testing.T) {
	AllocateDeviceInBulk()
}

func TestCreateTables(t *testing.T) {
	CreateTables()
}
func TestAllocateUserInBulk(t *testing.T) {
	AllocateUserInBulk()
}
