package repositories

import (
	"context"
	"data-api/data_service/model"
	database "data-api/shared/db"
	"database/sql"
	"errors"
	"log"
	"strings"
)

var deviceAllocationList []model.DeviceAllocation
var userAllocationList []model.UserAllocation
var UUID = "TIHRO1245ROHIT"

type DBSelector struct {
	sqdb *sql.DB
}

type DedicatedDBConnection func(conn *sql.Conn) error

// var dropAllocationTable = "IF OBJECT_ID('allocation', 'U') IS NOT NULL DROP TABLE allocation;"

var bulkUpsert = `
IF ((select count(*) from allocation where DeviceSerial= @DeviceSerial AND LicenseKey= @LicenseKey) =1)
UPDATE allocation
 SET
 DeviceSerial = @DeviceSerial,
 DeviceName = @DeviceName,
 LicenseKey= @LicenseKey,
 LicenseExpiryDate = @LicenseExpiryDate,
 AllocationReason = @AllocationReason,
 ExemptionReason = @ExemptionReason
 WHERE DeviceSerial= @DeviceSerial AND LicenseKey= @LicenseKey;
ELSE
INSERT INTO allocation(DeviceSerial,DeviceName,LicenseKey,LicenseExpiryDate,AllocationReason,ExemptionReason)
VALUES (@DeviceSerial,@DeviceName,@LicenseKey,@LicenseExpiryDate, @AllocationReason,@ExemptionReason);`

var licenseTable = `CREATE TABLE license(
	LicenseId int IDENTITY(1,1) NOT NULL,
	UUID nvarchar(50) NULL

CONSTRAINT PK_license_LicenseId PRIMARY KEY CLUSTERED
(
	LicenseId ASC
) ON [PRIMARY]);`

var GetLicenseIdQuery = `SELECT l.LicenseId from dbo.license l where l.UUID = @LicenseUUID`

var userTable = `CREATE TABLE cuser(
	UserId int IDENTITY(1,1) NOT NULL,
	AccountName nvarchar(50) NULL,
	UserEmailAddress nvarchar(50) NULL,
	DomainId int
	
CONSTRAINT PK_cuser_UserId PRIMARY KEY CLUSTERED
(
	UserId ASC
) ON [PRIMARY]);`

var domainTable = `CREATE TABLE domain(
	DomainId int IDENTITY(1,1) NOT NULL,
	DomainName nvarchar(50) NULL
	
CONSTRAINT PK_domain_DomainId PRIMARY KEY CLUSTERED
(
	DomainId ASC
) ON [PRIMARY]);`

var GetUserIDByAccountNameEmailQuery = `SELECT u.UserId from dbo.cuser u 
JOIN dbo.domain d ON u.DomainId = d.DomainId
where d.DomainName = @DomainName 
AND u.AccountName = @AccountName
AND u.UserEmailAddress = @UserEmailAddress`

var GetUserIDByAccountNameQuery = `SELECT u.UserId from dbo.cuser u 
JOIN dbo.domain d ON u.DomainId = d.DomainId
where d.DomainName = @DomainName 
AND u.AccountName = @AccountName`

var GetUserIDByEmailQuery = `SELECT u.UserId from dbo.cuser u 
where u.UserEmailAddress = @UserEmailAddress`

var licenseKeyTable = `CREATE TABLE licensekey(
	LicenseKeyId int IDENTITY(1,1) NOT NULL,
	LicenseId int,
	LicenseKey nvarchar(50) NULL,
	LicenseExpiryDate datetime2(3) NULL

CONSTRAINT PK_licensekey_LicenseKeyId PRIMARY KEY CLUSTERED
(
	LicenseKeyId ASC
) ON [PRIMARY]);`

var licenseExemptionTable = `CREATE TABLE licenseexemption(
	ExemptionId int IDENTITY(1,1) NOT NULL,
	ExemptionReason nvarchar(50) NULL	
CONSTRAINT PK_licenseexemption_ExemptionId PRIMARY KEY CLUSTERED
(
	ExemptionId ASC
) ON [PRIMARY]);`

var licenseAllocationTable = `CREATE TABLE licenseallocation(
	LicenseAllocationId int IDENTITY(1,1) NOT NULL,
	LicenseKeyId int,
	UserId int,
	LicenseId int,
	ExemptionId int,
	AllocationReason nvarchar(50) NULL
CONSTRAINT PK_licenseallocation_LicenseAllocationId PRIMARY KEY CLUSTERED
(
	LicenseAllocationId ASC
) ON [PRIMARY]);`

var licenseKeyUpsertQuery = `
IF ((select count(*) from dbo.licensekey where LicenseKey= @LicenseKey and LicenseId=@LicenseId ) =1)
UPDATE dbo.licensekey
 SET
 LicenseExpiryDate = @LicenseExpiryDate 
 OUTPUT INSERTED.LicenseKeyId 
 WHERE LicenseKey= @LicenseKey and LicenseId=@LicenseId;
ELSE
INSERT INTO dbo.licensekey(LicenseKey,LicenseId, LicenseExpiryDate)
OUTPUT INSERTED.LicenseKeyId
VALUES (@LicenseKey,@LicenseId,@LicenseExpiryDate);`

var licenseExemptionUpsertQuery = `
IF ((select count(*) from dbo.licenseexemption where ExemptionReason= @ExemptionReason) =1)
select le.ExemptionId from dbo.licenseexemption le where le.ExemptionReason= @ExemptionReason;
ELSE
INSERT INTO dbo.licensekey(ExemptionReason)
OUTPUT INSERTED.ExemptionId
VALUES (@ExemptionReason);`

var licenseAllocationUpsertQuery = `
IF ((select count(*) from dbo.licenseallocation where UserId= @UserId AND LicenseId= @LicenseId) =1)
UPDATE dbo.licenseallocation
 SET
 AllocationReason = @AllocationReason
 WHERE UserId= @UserId AND LicenseId= @LicenseId;
ELSE
INSERT INTO dbo.licenseallocation(LicenseKeyId, UserId, LicenseId, ExemptionId, AllocationReason)
VALUES (@LicenseKeyId,@UserId,@LicenseId,@ExemptionId, @AllocationReason);`

func GetDeviceAllocationList() []model.DeviceAllocation {
	deviceAllocation1 := model.DeviceAllocation{
		DeviceSerial:      "ABC1-101",
		DeviceName:        "ABC1-Rohit",
		LicenseKey:        "ABC-23121989",
		LicenseExpiryDate: "2023-10-11T02:18:37.753Z",
		AllocationReason:  "Development",
		ExemptionReason:   "",
		ErrorMessage:      "",
	}

	deviceAllocation2 := model.DeviceAllocation{
		DeviceSerial:      "ABC2-102",
		DeviceName:        "ABC2",
		LicenseKey:        "ABC-56789",
		LicenseExpiryDate: "2024-01-11T02:18:37.753Z",
		AllocationReason:  "Pro Development",
		ExemptionReason:   "",
		ErrorMessage:      "",
	}

	deviceAllocationList = append(deviceAllocationList, deviceAllocation1)
	deviceAllocationList = append(deviceAllocationList, deviceAllocation2)
	return deviceAllocationList
}

func GetUserAllocationList() *[]model.UserAllocation {
	userAllocation1 := model.UserAllocation{
		AccountName:       "flex\\rbhilare",
		UserEmailAddress:  "rbhilare@flex.com",
		LicenseKey:        "ABC-23121989",
		LicenseExpiryDate: "2023-10-11T02:18:37.753Z",
		AllocationReason:  "Development",
		ExemptionReason:   "",
		ErrorMessage:      "",
	}

	userAllocation2 := model.UserAllocation{
		AccountName:       "flex\\rbhilare",
		UserEmailAddress:  "rbhilare@flex.com",
		LicenseKey:        "PQR-56789",
		LicenseExpiryDate: "2024-01-11T02:18:37.753Z",
		AllocationReason:  "Pro Development",
		ExemptionReason:   "",
		ErrorMessage:      "",
	}

	userAllocation3 := model.UserAllocation{
		AccountName:       "flex\\spatil",
		UserEmailAddress:  "spatil@flex.com",
		LicenseKey:        "PQR-1234",
		LicenseExpiryDate: "2002-01-11T02:18:37.753Z",
		AllocationReason:  "Expert Development",
		ExemptionReason:   "Just dev not for prod",
		ErrorMessage:      "",
	}
	userAllocationList = append(userAllocationList, userAllocation1)
	userAllocationList = append(userAllocationList, userAllocation2)
	userAllocationList = append(userAllocationList, userAllocation3)
	return &userAllocationList
}

func CreateTables() {
	db, err := database.GetConnection()
	if err != nil {
		log.Println("CreateTables connection err: ", err)
	}

	// Create table
	_, err = db.Exec(licenseTable)
	if err != nil {
		log.Println(err)
	}

	// Create table
	_, err = db.Exec(userTable)
	if err != nil {
		log.Println(err)
	}

	// Create table
	_, err = db.Exec(domainTable)
	if err != nil {
		log.Println(err)
	}

	// Create table
	_, err = db.Exec(licenseKeyTable)
	if err != nil {
		log.Println(err)
	}

	// Create table
	_, err = db.Exec(licenseExemptionTable)
	if err != nil {
		log.Println(err)
	}

	// Create table
	_, err = db.Exec(licenseAllocationTable)
	if err != nil {
		log.Println(err)
	}
}

func (d *DBSelector) DedicatedConnection(wrappedFunc DedicatedDBConnection) (err error) {
	if wrappedFunc == nil {
		return errors.New("wrappedFunc is required")
	}
	ctx, _ := context.WithCancel(context.Background())
	db, err := database.GetConnection()
	if err != nil {
		log.Println("CreateTables connection err: ", err)
	}

	conn, err := db.Conn(ctx)
	if err != nil {
		log.Println("conn connection err: ", err)
	}
	defer conn.Close()

	if err := wrappedFunc(conn); err != nil {
		log.Println("wrappedFunc execution  err: ", err)
		return err
	}
	return nil
}

func AllocateUserInBulk() {
	ctx, _ := context.WithCancel(context.Background())
	var LicenseID int
	batchSize := 10
	dbSelector := DBSelector{}
	err := dbSelector.DedicatedConnection(func(conn *sql.Conn) error {
		row := conn.QueryRowContext(ctx, GetLicenseIdQuery, sql.NamedArg{Name: "LicenseUUID", Value: UUID})
		err := row.Scan(&LicenseID)
		log.Println("LicenseID: -> ", LicenseID)
		if err != nil {
			log.Println("error running GetLicenseIdQuery err: ", err)
		}
		return nil
	})

	if err != nil {
		log.Println("error getting GetLicenseIdQuery err: ", err)
	}

	if LicenseID == 0 {
		log.Println("error getting GetLicenseIdQuery LicenseID err: ", err)
	}

	userAllocList := GetUserAllocationList()

	err = dbSelector.DedicatedConnection(func(conn *sql.Conn) error {
		tx, err := conn.BeginTx(ctx, &sql.TxOptions{})
		if err != nil {
			log.Println("error creating transaction err: ", err)
		}
		var counter int
		// for i := 0; i < len(*userAllocList); i++ {
		// 	alloc := userAllocList[i]
		for idx, alloc := range *userAllocList {
			counter++
			recordProcessErr := false
			var UserID int
			var LicenseKeyId int
			var ExceptionReasonId int

			if recordProcessErr {
				if e := tx.Rollback(); e != nil {
					log.Println("Rollback err: -> ", e)
				}
				recordProcessErr = false
				continue
			}

			if alloc.AccountName != "" && alloc.UserEmailAddress != "" {
				splitAccountName := strings.Split(alloc.AccountName, "\\")
				if len(splitAccountName) == 2 {
					domainAccountName := splitAccountName[0]
					accountName := splitAccountName[1]
					rowByNameAndEmail := tx.QueryRowContext(ctx, GetUserIDByAccountNameEmailQuery, sql.Named("DomainName", domainAccountName),
						sql.Named("AccountName", accountName),
						sql.Named("UserEmailAddress", alloc.UserEmailAddress))
					err := rowByNameAndEmail.Scan(&UserID)
					log.Println("rowByNameAndEmail UserID: -> ", UserID)
					if err != nil {
						recordProcessErr = true
						alloc.ErrorMessage = "user does not exists"
						log.Println("error running GetUserIDByAccountNameEmailQuery err: ", err)
					}
				} else {
					recordProcessErr = true
					alloc.ErrorMessage = "user does not exists"
					log.Println("error running GetUserIDByAccountNameEmailQuery err: ", err)
				}
			}

			if alloc.AccountName != "" && UserID == 0 {
				recordProcessErr = false
				splitAccountName := strings.Split(alloc.AccountName, "\\")
				if len(splitAccountName) == 2 {
					domainAccountName := splitAccountName[0]
					accountName := splitAccountName[1]
					rowByName := tx.QueryRowContext(ctx, GetUserIDByAccountNameQuery, sql.Named("DomainName", domainAccountName),
						sql.Named("AccountName", accountName))
					err := rowByName.Scan(&UserID)
					log.Println("rowByName UserID: -> ", UserID)
					if err != nil {
						recordProcessErr = true
						alloc.ErrorMessage = "user does not exists"
						log.Println("error running GetUserIDByAccountNameQuery err: ", err)
					}
				}
			}
			if alloc.UserEmailAddress != "" && UserID == 0 {
				recordProcessErr = false
				rowByName := tx.QueryRowContext(ctx, GetUserIDByEmailQuery,
					sql.Named("UserEmailAddress", alloc.UserEmailAddress))
				err := rowByName.Scan(&UserID)
				log.Println("rowByName UserID: -> ", UserID)
				if err != nil {
					recordProcessErr = true
					alloc.ErrorMessage = "user does not exists"
					log.Println("error running GetUserIDByEmailQuery err: ", err)
				}
			}

			if recordProcessErr {
				log.Println("recordProcessErr at index:", idx, " object: ", alloc, " err: ", recordProcessErr)
				continue
			}

			// stmtLicenseKey, err := tx.Prepare(licenseKeyUpsertQuery)
			// if err != nil {
			// 	recordProcessErr = true
			// 	alloc.ErrorMessage = "error preparing transaction " + err.Error()
			// 	log.Println("error preparing transaction licenseKeyUpsertQuery err: ", err)
			// }

			// _, err = stmtLicenseKey.Exec(sql.Named("LicenseKey", alloc.LicenseKey),
			// 	sql.Named("LicenseExpiryDate", alloc.LicenseExpiryDate))
			// if err != nil {
			// 	recordProcessErr = true
			// 	alloc.ErrorMessage = "error in executing query" + err.Error()
			// 	log.Println("error executing query licenseKeyUpsertQuery err: ", err)
			// }
			if alloc.LicenseKey != "" {
				recordProcessErr = false
				row := tx.QueryRow(licenseKeyUpsertQuery, sql.Named("LicenseKey", alloc.LicenseKey),
					sql.Named("LicenseId", LicenseID),
					sql.Named("LicenseExpiryDate", alloc.LicenseExpiryDate))

				err = row.Scan(&LicenseKeyId)
				if err != nil {
					recordProcessErr = true
					alloc.ErrorMessage = "error in executing query" + err.Error()
					log.Println("error executing query licenseKeyUpsertQuery err: ", err)
				}

				// if recordProcessErr {
				// 	log.Println("recordProcessErr at index:", idx, " object: ", alloc, " err: ", recordProcessErr)
				// 	continue
				// }
			}

			if alloc.ExemptionReason != "" {
				recordProcessErr = false
				row := tx.QueryRow(licenseExemptionUpsertQuery, sql.Named("ExemptionReason", alloc.ExemptionReason))

				err = row.Scan(&ExceptionReasonId)
				if err != nil {
					recordProcessErr = true
					alloc.ErrorMessage = "error in executing query" + err.Error()
					log.Println("error executing query licenseExemptionUpsertQuery err: ", err)
				}

				// if recordProcessErr {
				// 	log.Println("recordProcessErr at index:", idx, " object: ", alloc, " err: ", recordProcessErr)
				// 	continue
				// }
			}
			recordProcessErr = false
			stmt, err := tx.Prepare(licenseAllocationUpsertQuery)
			if err != nil {
				recordProcessErr = true
				alloc.ErrorMessage = "error preparing transaction" + err.Error()
				log.Println("error preparing transaction licenseAllocationUpsertQuery err: ", err)
			}
			if recordProcessErr {
				log.Println("recordProcessErr at index:", idx, " object: ", alloc, " err: ", recordProcessErr)
				continue
			}
			_, err = stmt.Exec(sql.Named("LicenseKeyId", LicenseKeyId),
				sql.Named("UserId", UserID),
				sql.Named("LicenseId", LicenseID),
				sql.Named("ExemptionId", ExceptionReasonId),
				sql.Named("AllocationReason", alloc.AllocationReason))
			if err != nil {
				recordProcessErr = true
				alloc.ErrorMessage = "error in executing query licenseAllocationUpsertQuery" + err.Error()
				log.Println("error executing query licenseAllocationUpsertQuery err: ", err)
			}
			if recordProcessErr {
				log.Println("recordProcessErr at index:", idx, " object: ", alloc, " err: ", recordProcessErr)
				continue
			}

			if counter == batchSize {
				err = tx.Commit()
				if err != nil {
					log.Fatal(err)
				}
				counter = 0
			}

		} // end of for

		err = tx.Commit()
		if err != nil {
			log.Fatal(err)
		}
		return nil
	})

	if err != nil {
		log.Println("error executing transaction err: ", err)
	}
	log.Println("After Processing userAllocList : ", userAllocList)

}

func AllocateDeviceInBulk() {
	db, err := database.GetConnection()
	if err != nil {
		log.Println("allocateInBulk connection err: ", err)
	}
	tx, err := db.Begin()
	if err != nil {
		log.Println("Transaction Begin err: ", err)
	}

	// Create table
	// _, err = db.Exec(createAllocationTable)
	// if err != nil {
	// 	log.Println(err)
	// }
	//defer db.Exec(dropAllocationTable)
	stmt, err := tx.Prepare(bulkUpsert)
	if err != nil {
		log.Println(err)
	}
	deviceAllocList := GetDeviceAllocationList()
	for _, allocObj := range deviceAllocList {
		log.Println(allocObj)
		// var params []interface{}
		// params = append(params, sql.Named("DeviceSerial", allocObj.DeviceSerial),
		// 	sql.Named("DeviceName", allocObj.DeviceName),
		// 	sql.Named("LicenseKey", allocObj.LicenseKey),
		// 	sql.Named("LicenseExpiryDate", allocObj.LicenseExpiryDate),
		// 	sql.Named("AllocationReason", allocObj.AllocationReason),
		// 	sql.Named("ExemptionReason", allocObj.ExemptionReason))

		result, err := stmt.Exec(sql.Named("DeviceSerial", allocObj.DeviceSerial),
			sql.Named("DeviceName", allocObj.DeviceName),
			sql.Named("LicenseKey", allocObj.LicenseKey),
			sql.Named("LicenseExpiryDate", allocObj.LicenseExpiryDate),
			sql.Named("AllocationReason", allocObj.AllocationReason),
			sql.Named("ExemptionReason", allocObj.ExemptionReason))
		if err != nil {
			log.Println(err.Error())
		}

		rowCount, _ := result.RowsAffected()
		log.Printf("%d row copied\n", rowCount)
	}

	// result, err := stmt.Exec()
	// if err != nil {
	// 	log.Fatal(err)
	// }

	err = stmt.Close()
	if err != nil {
		log.Fatal(err)
	}

	err = tx.Commit()
	if err != nil {
		log.Fatal(err)
	}

	log.Printf("bye\n")
}
