package model

type DeviceAllocation struct {
	DeviceSerial      string
	DeviceName        string
	LicenseKey        string
	LicenseExpiryDate string
	AllocationReason  string
	ExemptionReason   string
	ErrorMessage      string
}

type UserAllocation struct {
	AccountName       string
	UserEmailAddress  string
	LicenseKey        string
	LicenseExpiryDate string
	AllocationReason  string
	ExemptionReason   string
	ErrorMessage      string
}
